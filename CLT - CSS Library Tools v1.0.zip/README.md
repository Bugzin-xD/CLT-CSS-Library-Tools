# CLT (CSS Library Tools)

Uma biblioteca leve de CSS e JavaScript focada em produtividade, simplicidade e customização.

---

# Sobre

O CLT (CSS Library Tools) foi criado para acelerar o desenvolvimento front-end utilizando HTML, CSS e JavaScript nativos.

Em vez de substituir a forma como você constrói sites, o CLT automatiza tarefas repetitivas enquanto mantém seu código limpo, legível e fácil de customizar.

A biblioteca combina CSS moderno, JavaScript leve e recursos nativos do navegador para criar interfaces responsivas com o mínimo de código.

---

# Recursos

* **Sistema de Temas:** Totalmente controlado por Variáveis CSS.
* **Baseado em Componentes:** Elementos estruturais e de interface prontos para uso.
* **Helpers Inteligentes em JS:** Automação de scripts nativos sem códigos repetitivos (*boilerplate*).
* **Labels Flutuantes Automáticas:** Gerenciadas automaticamente através de atributos.
* **Revelar Senha:** Funcionalidade nativa de alternância para inputs de senha.
* **Estados de Botão:** Atributos dedicados para estados ativo, desativado e de carregamento.
* **Alertas Automáticos:** Elementos de alerta customizados prontos para uso.
* **Utilitários Práticos:** Configuração rápida para Copiar para a Área de Transferência e Downloads de arquivos.
* **Layouts Responsivos:** Sistemas flexíveis de containers e grids.
* **Estética:** Barras de rolagem personalizadas e animações de revelação ao rolar a página (*scroll-reveal*).
* **Performance:** Zero dependências externas.

---

# Instalação

Inclua os arquivos necessários na tag `<head>` e no final do `<body>` do seu projeto:

```html
<!-- Dentro do <head> -->
<link rel="stylesheet" href="clt-dark-minimalist.css">
<link rel="stylesheet" href="clt.min.css">

<!-- Antes do fechamento do </body> -->
<script src="clt-functions.js"></script>
```

---

# Componentes

## Card

```html
<div class="clt-card">
    <h2 class="clt-card-title">Título do Card</h2>
    <p class="clt-card-text">Texto do card.</p>
    <button class="clt-card-button">Botão</button>
</div>
```

---

## Tipografia & Links

### Título
```html
<h1 class="clt-title">Olá Mundo</h1>
```

### Parágrafo
```html
<p class="clt-p">Parágrafo.</p>
```

### Link
```html
<a class="clt-link">Link</a>
```

---

## Inputs & Formulários

### Input Inteligente
Basta usar o atributo `clt` para gerar automaticamente uma Label Flutuante, Grupo de Input, Layout Responsivo e Placeholder:

```html
<input clt="Nome">
```

### Revelar Senha
Cria automaticamente um controle de exibir/ocultar senha adicionando o atributo `reveal`:

```html
<input type="password" clt="Senha" reveal>
```

---

## Botões & Estados

### Padrão
```html
<button class="clt-card-button">Botão</button>
```

### Ativo
```html
<button class="clt-card-button" clt="on">Botão</button>
```

### Desativado
```html
<button class="clt-card-button" clt="off">Botão</button>
```

### Carregando
```html
<button class="clt-card-button" clt="loading">Carregando...</button>
```

---

## Alertas

### Padrão
```html
<clt-alert>Mensagem</clt-alert>
```

### Aviso
```html
<clt-alert type="warn">Mensagem</clt-alert>
```

### Perigo / Erro
```html
<clt-alert type="alert">Mensagem</clt-alert>
```

---

## Loader (Carregamento)

```html
<div class="clt-loader"></div>
```

---

## JavaScript Helpers (Utilitários)

### Copiar para a Área de Transferência
Copie facilmente o conteúdo de texto de qualquer elemento referenciando o ID dele:

```html
<pre id="codigo-exemplo">Olá Mundo</pre>

<button class="clt-card-button" clt-copy="codigo-exemplo">Copiar</button>
```

### Auxiliar de Download
Dispare downloads de arquivos locais instantaneamente:

```html
<button class="clt-card-button" clt-download="clt-v1.0.zip">Download</button>
```

Você também pode especificar um nome personalizado para o arquivo baixado:

```html
<button class="clt-card-button" clt-download="downloads/library.zip" download-name="CLT.zip">Download</button>
```

---

## Layout & Estrutura

### Navegação & Headers
```html
<header class="clt-header"></header>
<nav class="clt-navbar"></nav>
```

### Estrutura Principal
```html
<main class="clt-main"></main>
<section class="clt-section"></section>
<div class="clt-container"></div>
```

### Centralização de Elementos
```html
<div class="clt-center"></div>
<!-- ou -->
<div class="clt-flex-center"></div>
```

### Rodapé
```html
<footer class="clt-footer">
    <p class="clt-footer-text">Rodapé</p>
    <p class="clt-footer-right">Loaden TI</p>
</footer>
```

---

## Animação de Rolagem (Scroll)

Aplique a classe na tag `<body>` e cada elemento filho direto será animado suavemente ao entrar na tela (*viewport*):

```html
<body class="clt-animation-scroll">
```

---

# Customização

O CLT é totalmente baseado em Variáveis CSS. Você pode sobrescrever qualquer variável dentro do seu próprio arquivo `:root` sem precisar mexer nos arquivos principais da biblioteca.

Exemplo:

```css
:root {
    --clt-surface: #202020;
    --clt-text: #ffffff;
    --clt-border-color: #00aaff;
}
```

---

# Boilerplate (Modelo Pronto)

Aqui está um modelo HTML pronto para uso contendo a estrutura básica para começar a desenvolver com o CLT instantaneamente:

```html
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modelo de Projeto CLT</title>
    
    <!-- Estilos CSS do CLT -->
    <link rel="stylesheet" href="clt-dark-minimalist.css">
    <link rel="stylesheet" href="clt.min.css">
</head>
<body class="clt-animation-scroll">

    <!-- Barra de Navegação -->
    <nav class="clt-navbar">
        <h1 class="clt-title">Meu App</h1>
    </nav>

    <!-- Container Principal -->
    <div class="clt-container clt-flex-center">
        <main class="clt-main">
            <div class="clt-card">
                <h2 class="clt-card-title">Bem-vindo ao CLT</h2>
                <p class="clt-card-text">Comece a construir sua interface limpa aqui.</p>
                
                <!-- Exemplo de Formulário Inteligente -->
                <input clt="Endereço de E-mail">
                <input type="password" clt="Senha" reveal>
                
                <button class="clt-card-button">Começar</button>
            </div>
        </main>
    </div>

    <!-- Rodapé -->
    <footer class="clt-footer">
        <p class="clt-footer-text">© 2026 Meu Projeto</p>
        <p class="clt-footer-right">Desenvolvido com CLT</p>
    </footer>

    <!-- Funções JavaScript do CLT -->
    <script src="clt-functions.js"></script>
</body>
</html>
```

---

# Filosofia

O CLT segue quatro princípios fundamentais:
* **Simplicidade:** Mantenha o código limpo, leve e fácil de entender.
* **Performance:** Renderização de alta velocidade com tecnologia nativa e zero dependências.
* **Integração Nativa:** Funciona a favor do seu fluxo de trabalho, não contra ele.
* **Customização:** Controle total sobre os temas através de Variáveis CSS.

---

# Suporte de Navegadores

Navegadores modernos recomendados e testados:
* Google Chrome
* Microsoft Edge
* Mozilla Firefox
* Opera
* Brave

---

# Licença

Copyright © Loaden TI. Todos os direitos reservados.